-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: d_gymdb
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_avance`
--

DROP TABLE IF EXISTS `tb_avance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_avance` (
  `tb_clientes` int(11) NOT NULL,
  `tb_rutina` int(11) NOT NULL,
  `tb_entrenadores` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  KEY `fk_tb_avance_tb_clientes1_idx` (`tb_clientes`),
  KEY `fk_tb_avance_tb_rutina1_idx` (`tb_rutina`),
  KEY `fk_tb_avance_tb_entrenadores1_idx` (`tb_entrenadores`),
  CONSTRAINT `fk_tb_avance_tb_clientes1` FOREIGN KEY (`tb_clientes`) REFERENCES `tb_clientes` (`id_clientes`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tb_avance_tb_entrenadores1` FOREIGN KEY (`tb_entrenadores`) REFERENCES `tb_entrenadores` (`id_entrenadores`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tb_avance_tb_rutina1` FOREIGN KEY (`tb_rutina`) REFERENCES `tb_rutina` (`id_rutina`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_avance`
--

LOCK TABLES `tb_avance` WRITE;
/*!40000 ALTER TABLE `tb_avance` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_avance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_ciudades`
--

DROP TABLE IF EXISTS `tb_ciudades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ciudades` (
  `id_ciudades` int(11) NOT NULL,
  `descripcion` varchar(60) DEFAULT NULL,
  `tb_departamentos_id_departamentos` int(11) NOT NULL,
  PRIMARY KEY (`id_ciudades`),
  KEY `fk_tb_ciudades_tb_departamentos1_idx` (`tb_departamentos_id_departamentos`),
  CONSTRAINT `fk_tb_ciudades_tb_departamentos1` FOREIGN KEY (`tb_departamentos_id_departamentos`) REFERENCES `tb_departamentos` (`id_departamentos`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_ciudades`
--

LOCK TABLES `tb_ciudades` WRITE;
/*!40000 ALTER TABLE `tb_ciudades` DISABLE KEYS */;
INSERT INTO `tb_ciudades` VALUES (1,'Asunción',1),(2,'Bahía Negra',17),(3,'Carmelo Peralta',17),(4,'Puerto Casado',17),(5,'Fuerte Olimpo',17),(6,'Ciudad del Este',11),(7,'Doctor Juan León Mallorquín',11),(8,'Doctor Raúl Peña',11),(9,'Domingo Martínez de Irala',11),(10,'Hernandarias',11),(11,'Iruña',11),(12,'Itakyry',11),(13,'Juan E. O´Leary',11),(14,'Los Cedrales',11),(15,'Mbaracayú',11),(16,'Minga Guazú',11),(17,'Minga Porá',11),(18,'Naranjal',11),(19,'Ñacunday',11),(20,'Presidente Franco',11),(21,'San Alberto',11),(22,'San Cristóbal',11),(23,'Santa Fe del Paraná',11),(24,'Santa Rita',11),(25,'Santa Rosa del Monday',11),(26,'Tavapy',11),(27,'Colonia Yguazú',11),(28,'Bella Vista Norte',13),(29,'Capitán Bado',13),(30,'Pedro Juan Caballero',13),(31,'Zanja Pytá',13),(32,'Karapaí',13),(33,'Filadelfia',16),(34,'Loma Plata',16),(35,'Mcal. Estigarribia',16),(36,'Caaguazú',6),(37,'Carayaó',6),(38,'Cnel. Oviedo',6),(39,'Doctor Cecilio Báez',6),(40,'J.E. Estigarribia',6),(41,'Campo 9',6),(42,'Doctor Juan Manuel Frutos',6),(43,'José Domingo Ocampos',6),(44,'La Pastora',6),(45,'Mcal. Francisco S. López',6),(46,'Nueva Londres',6),(47,'Nueva Toledo',6),(48,'Raúl Arsenio Oviedo',6),(49,'Repatriación',6),(50,'R. I. Tres Corrales',6),(51,'San Joaquín',6),(52,'San José de los Arroyos',6),(53,'Mbutuy',6),(54,'Simón Bolívar',6),(55,'Tembiaporá',6),(56,'Tres de Febrero',6),(57,'Vaquería',6),(58,'Yhú',6),(59,'3 de Mayo',7),(60,'Abaí',7),(61,'Buena Vista',7),(62,'Caazapá',7),(63,'Doctor Moisés S. Bertoni',7),(64,'Fulgencio Yegros',7),(65,'General Higinio Morínigo',7),(66,'Maciel',7),(67,'San Juan Nepomuceno',7),(68,'Tavaí',7),(69,'Yuty',7),(70,'Colonia Anahí',14),(71,'Corpus Christi',14),(72,'Curuguaty',14),(73,'Gral. Francisco Caballero Álvarez',14),(74,'Itanará',14),(75,'Katueté',14),(76,'La Paloma',14),(77,'Maracaná',14),(78,'Nueva Esperanza',14),(79,'Salto del Guairá',14),(80,'Villa Ygatimí',14),(81,'Yasy Cañy',14),(82,'Ybyrarovaná',14),(83,'Ypejhú',14),(84,'Yby Pytá',14),(85,'Areguá',1),(86,'Capiatá',1),(87,'Fernando de la Mora',1),(88,'Guarambaré',1),(89,'Itá',1),(90,'Itauguá',1),(91,'J. Augusto Saldivar',1),(92,'Lambaré',1),(93,'Limpio',1),(94,'Luque',1),(95,'Mariano Roque Alonso',1),(96,'Ñemby',1),(97,'Nueva Italia',1),(98,'San Antonio',1),(99,'San Lorenzo',1),(100,'Villa Elisa',1),(101,'Villeta',1),(102,'Ypacaraí',1),(103,'Ypané',1),(104,'Arroyito',2),(105,'Azotey',2),(106,'Belén',2),(107,'Concepción',2),(108,'Horqueta',2),(109,'Loreto',2),(110,'San Carlos del Apa',2),(111,'San Lázaro',2),(112,'Yby Yaú',2),(113,'Sargento José Félix López',2),(114,'San Alfredo',2),(115,'Paso Barreto',2),(116,'Altos',4),(117,'Arroyos y Esteros',4),(118,'Atyrá',4),(119,'Caacupé',4),(120,'Caraguatay',4),(121,'Emboscada',4),(122,'Eusebio Ayala',4),(123,'Isla Pucú',4),(124,'Itacurubí',4),(125,'Juan de Mena',4),(126,'Loma Grande',4),(127,'Mbocayaty del Yhaguy',4),(128,'Nueva Colombia',4),(129,'Piribebuy',4),(130,'Primero de Marzo',4),(131,'San Bernardino',4),(132,'San José Obrero',4),(133,'Santa Elena',4),(134,'Tobatí',4),(135,'Valenzuela',4),(136,'Borja',5),(137,'Colonia Independencia',5),(138,'Coronel Martínez',5),(139,'Dr. Bottrell',5),(140,'Fassardi',5),(141,'Félix Pérez Cardozo',5),(142,'Garay',5),(143,'Itapé',5),(144,'Iturbe',5),(145,'Mbocayaty',5),(146,'Natalicio Talavera',5),(147,'Ñumí',5),(148,'Paso Yobái',5),(149,'San Salvador',5),(150,'Tebicuary',5),(151,'Troche',5),(152,'Villarrica',5),(153,'Yataity',5),(154,'Alto Verá',8),(155,'Bella Vista',8),(156,'Cambyretá',8),(157,'Capitán Meza',8),(158,'Capitán Miranda',8),(159,'Carlos Antonio López',8),(160,'Carmen del Paraná',8),(161,'Coronel Bogado',8),(162,'Edelira',8),(163,'Encarnación',8),(164,'Fram',8),(165,'General Artigas',8),(166,'General Delgado',8),(167,'Hohenau',8),(168,'Itapúa Poty',8),(169,'Jesús',8),(170,'Colonia La Paz',8),(171,'José Leandro Oviedo',8),(172,'Mayor Otaño',8),(173,'Natalio',8),(174,'Nueva Alborada',8),(175,'Obligado',8),(176,'Pirapó',8),(177,'San Cosme y Damián',8),(178,'San Juan del Paraná',8),(179,'San Pedro del Paraná',8),(180,'San Rafael del Paraná',8),(181,'Maria Auxiliadora',8),(182,'Trinidad',8),(183,'Yatytay',8),(184,'Ayolas',9),(185,'San Ignacio',9),(186,'San Juan Bautista',9),(187,'San Miguel',9),(188,'San Patricio',9),(189,'Santa María',9),(190,'Santa Rosa',9),(191,'Santiago',9),(192,'Villa Florida',9),(193,'Yabebyry',9),(194,'Alberdi',12),(195,'Cerrito',12),(196,'Desmochados',12),(197,'General José Eduvigis Díaz',12),(198,'Guazú Cuá',12),(199,'Humaitá',12),(200,'Isla Umbú',12),(201,'Laureles',12),(202,'Mayor José J. Martínez',12),(203,'Paso de Patria',12),(204,'Pilar',12),(205,'San Juan Bautista del Ñeembucú',12),(206,'Tacuaras',12),(207,'Villa Franca',12),(208,'Villalbín',12),(209,'Villa Oliva',12),(210,'Acahay',10),(211,'Caapucú',10),(212,'Carapeguá',10),(213,'Escobar',10),(214,'Gral. Bernardino Caballero',10),(215,'La Colmena',10),(216,'María Antonia',10),(217,'Mbuyapey',10),(218,'Paraguarí',10),(219,'Pirayú',10),(220,'Quiindy',10),(221,'Quyquyhó',10),(222,'San Roque González de Santa Cruz',10),(223,'Sapucai',10),(224,'Tebicuarymí',10),(225,'Yaguarón',10),(226,'Ybycuí',10),(227,'Ybytymí',10),(228,'Benjamín Aceval',15),(229,'Dr. José Falcón',15),(230,'General José María Bruguez',15),(231,'Nanawa',15),(232,'Colonia Paratodo',15),(233,'Pozo Colorado',15),(234,'Puerto Pinasco',15),(235,'Tte. Irala Fernández',15),(236,'Esteban Martínez',15),(237,'Villa Hayes',15),(238,'Antequera',3),(239,'Capiibary',3),(240,'Choré',3),(241,'General Elizardo Aquino',3),(242,'General Isidoro Resquín',3),(243,'Guayaibí',3),(244,'Itacurubí del Rosario',3),(245,'Liberación',3),(246,'Lima',3),(247,'Rio Verde',3),(248,'Nueva Germania',3),(249,'San Estanislao',3),(250,'San Pablo',3),(251,'Villa de San Pedro',3),(252,'San Vicente Pancholo',3),(253,'Santa Rosa del Aguaray',3),(254,'Tacuatí',3),(255,'Unión',3),(256,'25 de Diciembre',3),(257,'Villa del Rosario',3),(258,'Yataity del Norte',3),(259,'Yrybucuá',3);
/*!40000 ALTER TABLE `tb_ciudades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_clientes`
--

DROP TABLE IF EXISTS `tb_clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_clientes` (
  `id_clientes` int(11) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `apellido` varchar(30) DEFAULT NULL,
  `cedula` varchar(12) NOT NULL,
  `ocupacion` varchar(60) DEFAULT NULL,
  `fecha_nac` date DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `tb_ciudades` int(11) NOT NULL,
  `altura` decimal(10,2) DEFAULT NULL,
  `peso` decimal(10,2) DEFAULT NULL,
  `imc` decimal(10,2) DEFAULT NULL,
  `estado` varchar(85) DEFAULT NULL,
  `tb_photos` int(11) NOT NULL,
  PRIMARY KEY (`id_clientes`),
  UNIQUE KEY `cedula_UNIQUE` (`cedula`),
  KEY `fk_tb_clientes_tb_ciudades1_idx` (`tb_ciudades`),
  KEY `tbphotos_idx` (`tb_photos`),
  CONSTRAINT `fk_tb_clientes_tb_ciudades1` FOREIGN KEY (`tb_ciudades`) REFERENCES `tb_ciudades` (`id_ciudades`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbphotos` FOREIGN KEY (`tb_photos`) REFERENCES `tb_photos` (`id_photos`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_clientes`
--

LOCK TABLES `tb_clientes` WRITE;
/*!40000 ALTER TABLE `tb_clientes` DISABLE KEYS */;
INSERT INTO `tb_clientes` VALUES (1000,'Alexander','Quintero','4556985','Lic. en Quimica','1998-10-12','ale_quintero@lasca.com','0991564785','Avda Fernando de la Mora esq Curupayty',1,1.59,65.50,25.91,'INACTIVO',110),(1001,'Manuel','Ortiz','4225556','Ing Quimico, Seguridad Ocupacional','1995-10-10','ma_ortiz95@gmail.com','0995556993','Avda Santa Teresa casi Madame Lynch',1,1.75,85.00,27.76,'ACTIVO',111);
/*!40000 ALTER TABLE `tb_clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_departamentos`
--

DROP TABLE IF EXISTS `tb_departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_departamentos` (
  `id_departamentos` int(11) NOT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `capital` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id_departamentos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_departamentos`
--

LOCK TABLES `tb_departamentos` WRITE;
/*!40000 ALTER TABLE `tb_departamentos` DISABLE KEYS */;
INSERT INTO `tb_departamentos` VALUES (1,'Central','Areguá'),(2,'Concepción','Concepción'),(3,'San Pedro','San Pedro de Ycuamandiyú'),(4,'Coordillera','Caacupé'),(5,'Guairá','Villarica'),(6,'Caaguazú','Coronel Oviedo'),(7,'Caazapá','Caazapá'),(8,'Itapúa','Encarnación'),(9,'Misiones','San Juan Bautista'),(10,'Paraguarí','Paraguarí'),(11,'Alto Paraná','Ciudad del Este'),(12,'Ñeembucú','Pilar'),(13,'Amambay','Pedro Juan Caballero'),(14,'Canindeyú','Salto del Guairá'),(15,'Presidente Hayes','Villa Hayes'),(16,'Boquerón','Filadelfia'),(17,'Alto Paraguay','Fuerte Olimpo');
/*!40000 ALTER TABLE `tb_departamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_entrenadores`
--

DROP TABLE IF EXISTS `tb_entrenadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_entrenadores` (
  `id_entrenadores` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `cedula` varchar(45) DEFAULT NULL,
  `formacion` varchar(100) DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `ciudad` int(11) NOT NULL,
  `edad` varchar(45) DEFAULT NULL,
  `id_tbphoto` int(11) DEFAULT NULL,
  `idtb_usuarios` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_entrenadores`),
  KEY `fk_tb_entrenadores_tb_ciudades1_idx` (`ciudad`),
  KEY `idphotos_idx` (`id_tbphoto`),
  CONSTRAINT `fk_tb_entrenadores_tb_ciudades1` FOREIGN KEY (`ciudad`) REFERENCES `tb_ciudades` (`id_ciudades`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `idphotos` FOREIGN KEY (`id_tbphoto`) REFERENCES `tb_photos` (`id_photos`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_entrenadores`
--

LOCK TABLES `tb_entrenadores` WRITE;
/*!40000 ALTER TABLE `tb_entrenadores` DISABLE KEYS */;
INSERT INTO `tb_entrenadores` VALUES (100,'Andres ','Ayala','3695226','Musculacion Personalizada, Especializacion en Deportiva Nutricional','Calle Manuel Ortiz Guerrero casi Acceso Sur',96,'28',109,NULL);
/*!40000 ALTER TABLE `tb_entrenadores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_fichacliente`
--

DROP TABLE IF EXISTS `tb_fichacliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_fichacliente` (
  `idfichacliente` int(11) NOT NULL AUTO_INCREMENT,
  `tb_clientes` int(11) NOT NULL,
  `periodocontrol` varchar(45) DEFAULT NULL,
  `fecha_lastcontrol` date DEFAULT NULL,
  `fecha_actual` date DEFAULT NULL,
  `pesoactual` decimal(10,2) DEFAULT NULL,
  `avance` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idfichacliente`),
  KEY `fk_tb_fichacliente_tb_clientes1_idx` (`tb_clientes`),
  CONSTRAINT `fk_tb_fichacliente_tb_clientes1` FOREIGN KEY (`tb_clientes`) REFERENCES `tb_clientes` (`id_clientes`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_fichacliente`
--

LOCK TABLES `tb_fichacliente` WRITE;
/*!40000 ALTER TABLE `tb_fichacliente` DISABLE KEYS */;
INSERT INTO `tb_fichacliente` VALUES (4,1000,'Mensual','2024-02-18','2024-03-18',84.30,'-2.95'),(5,1001,'Mensual','2024-01-22','2024-01-22',83.10,'-5.50'),(6,1001,'Mensual','2024-02-22','2024-03-22',82.50,'-2.50'),(7,1001,'Mensual','2024-03-20','2024-03-22',79.50,'-5.50');
/*!40000 ALTER TABLE `tb_fichacliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_moneda`
--

DROP TABLE IF EXISTS `tb_moneda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_moneda` (
  `id_moneda` int(11) NOT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `simbolo` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_moneda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_moneda`
--

LOCK TABLES `tb_moneda` WRITE;
/*!40000 ALTER TABLE `tb_moneda` DISABLE KEYS */;
INSERT INTO `tb_moneda` VALUES (100,'GUARANIES','GS'),(101,'DOLAR ESTADOUNIDENSE','USD'),(102,'EURO','EUR'),(103,'PESO ARGENTINO','ARG'),(104,'YEN JAPONES','YJP'),(105,'LIBRA ESTERLINA','GBP'),(106,'DOLAR CANADIENSE','CAD'),(107,'FRANCO SUIZO','CHF'),(108,'DOLAR HONGKONES','HKD'),(109,'YUAN CHINO','CNY'),(110,'DOLAR AUSTRALIANO','AUD'),(111,'REAL BRASILEÑO','BRL'),(112,'PESO CHILENO','CLP'),(113,'PESO COLOMBIANO','COP'),(114,'PESO URUGUAYO','UYU'),(115,'PESO MEXICANO','MXN'),(116,'NUEVO SOL','PEN'),(117,'BOLIVAR','VED'),(118,'BOLIVIANO','BS');
/*!40000 ALTER TABLE `tb_moneda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_pagos`
--

DROP TABLE IF EXISTS `tb_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_pagos` (
  `id_pagos` int(11) NOT NULL AUTO_INCREMENT,
  `nro_pago` int(11) NOT NULL,
  `tb_clientes` int(11) NOT NULL,
  `tb_plan` int(11) NOT NULL,
  `montopagado` decimal(10,2) DEFAULT NULL,
  `fecha_actual` date DEFAULT NULL,
  `validohasta` date DEFAULT NULL,
  PRIMARY KEY (`id_pagos`),
  KEY `fk_tb_pagos_tb_clientes1_idx` (`tb_clientes`),
  KEY `fk_tb_pagos_tb_plan1_idx` (`tb_plan`),
  CONSTRAINT `fk_tb_pagos_tb_clientes1` FOREIGN KEY (`tb_clientes`) REFERENCES `tb_clientes` (`id_clientes`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tb_pagos_tb_plan1` FOREIGN KEY (`tb_plan`) REFERENCES `tb_plan` (`idtb_plan`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pagos`
--

LOCK TABLES `tb_pagos` WRITE;
/*!40000 ALTER TABLE `tb_pagos` DISABLE KEYS */;
INSERT INTO `tb_pagos` VALUES (1,1,1000,9,60000.00,'2024-02-28','2024-01-15'),(3,2,1001,8,2000000.00,'2024-03-04','2025-03-04'),(8,4,1000,7,1000000.00,'2024-03-16','2024-03-16'),(10,10,1000,8,2000000.00,'2024-03-18','2024-03-09'),(11,11,1001,9,60000.00,'2024-03-18','2024-03-16');
/*!40000 ALTER TABLE `tb_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_photos`
--

DROP TABLE IF EXISTS `tb_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_photos` (
  `id_photos` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `ruta_subida` varchar(200) NOT NULL,
  `fecha_subida` datetime DEFAULT NULL,
  PRIMARY KEY (`id_photos`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_photos`
--

LOCK TABLES `tb_photos` WRITE;
/*!40000 ALTER TABLE `tb_photos` DISABLE KEYS */;
INSERT INTO `tb_photos` VALUES (109,'P.AYALA.jpg','../../pictures/photos/P.AYALA.jpg','2024-02-22 00:00:00'),(110,'LOGAN PAUL.jpg','../../pictures/photos/LOGAN PAUL.jpg','2024-02-22 00:00:00'),(111,'Clientes.png','../../pictures/photos/Clientes.png','2024-03-04 00:00:00');
/*!40000 ALTER TABLE `tb_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_plan`
--

DROP TABLE IF EXISTS `tb_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_plan` (
  `idtb_plan` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) DEFAULT NULL,
  `id_moneda` int(11) DEFAULT NULL,
  `costo` decimal(10,1) DEFAULT NULL,
  `cant_clases` varchar(45) DEFAULT NULL,
  `tb_users` int(11) NOT NULL,
  PRIMARY KEY (`idtb_plan`),
  KEY `idmoneda_idx` (`id_moneda`),
  CONSTRAINT `idmoneda` FOREIGN KEY (`id_moneda`) REFERENCES `tb_moneda` (`id_moneda`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_plan`
--

LOCK TABLES `tb_plan` WRITE;
/*!40000 ALTER TABLE `tb_plan` DISABLE KEYS */;
INSERT INTO `tb_plan` VALUES (7,'semestral',100,1000000.0,'120',0),(8,'anual',100,2000000.0,'240',0),(9,'quincenal',100,60000.0,'10',0),(12,'diario',100,10000.0,'1',0);
/*!40000 ALTER TABLE `tb_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_rol`
--

DROP TABLE IF EXISTS `tb_rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_rol` (
  `idtb_rol` int(11) NOT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idtb_rol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_rol`
--

LOCK TABLES `tb_rol` WRITE;
/*!40000 ALTER TABLE `tb_rol` DISABLE KEYS */;
INSERT INTO `tb_rol` VALUES (10,'administrador'),(20,'caja'),(30,'training');
/*!40000 ALTER TABLE `tb_rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_rutina`
--

DROP TABLE IF EXISTS `tb_rutina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_rutina` (
  `id_rutina` int(11) NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `calentamiento` varchar(100) DEFAULT NULL,
  `tiempo` varchar(45) DEFAULT NULL,
  `ejercicio1` varchar(100) DEFAULT NULL,
  `repeticiones1` varchar(40) DEFAULT NULL,
  `ejercicio2` varchar(100) DEFAULT NULL,
  `repeticiones2` varchar(45) DEFAULT NULL,
  `ejercicio3` varchar(100) DEFAULT NULL,
  `repeticiones3` varchar(45) DEFAULT NULL,
  `descanso` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_rutina`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_rutina`
--

LOCK TABLES `tb_rutina` WRITE;
/*!40000 ALTER TABLE `tb_rutina` DISABLE KEYS */;
INSERT INTO `tb_rutina` VALUES (70,'TRAINING WEEK 2','BICI ','10 minutos','Press inclinado con mancuernas','10 REPETICIONES 2 SERIES','Press de banca','5 REPETICIONES 3 SERIES',' Cruce de cables','30 REPETICIONES 2 SERIES','3 minutos');
/*!40000 ALTER TABLE `tb_rutina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_users`
--

DROP TABLE IF EXISTS `tb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_users` (
  `idtb_users` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `usuario` varchar(15) NOT NULL,
  `password` varchar(45) NOT NULL,
  `tb_roll` int(11) NOT NULL,
  PRIMARY KEY (`idtb_users`),
  KEY `fk_tb_users_tb_rol_idx` (`tb_roll`),
  CONSTRAINT `fk_tb_users_tb_rol` FOREIGN KEY (`tb_roll`) REFERENCES `tb_rol` (`idtb_rol`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10103 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_users`
--

LOCK TABLES `tb_users` WRITE;
/*!40000 ALTER TABLE `tb_users` DISABLE KEYS */;
INSERT INTO `tb_users` VALUES (10100,'CHARLY INSFRAN','RODRIGUEZ','DCHR@LOCALHOST.COM','0992582288','admin','d033e22ae348aeb5660fc2140aec35850c4da997',10),(10101,'Jorge Manuel','Iturbe','jotaiturbe@hotmail.com','025 455 855','jotama','2b5aad97872088447538eb610c576bf4da80517c',20);
/*!40000 ALTER TABLE `tb_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-06 18:58:55
